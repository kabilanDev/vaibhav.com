# Side Navbar 🧩

Responsive side Navigation Bar built using [Bootstrap 5](https://getbootstrap.com/).

<p align="center">
  <img src="./screenshots/concept.gif" width="auto" alt="Bits&Pieces Demo">
</p>

Codepen Link 🖋️- [https://codepen.io/jainharshit/pen/bGBRyLP](https://codepen.io/jainharshit/pen/bGBRyLP)
